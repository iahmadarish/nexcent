import React from 'react'

const Clients = () => {
  return (
    <>
        <div className='max-w-6xl mx-auto text-center mb-[40px]'>
            <div className='mb-[8px]'>
                <h1 className='text-[36px] text-[#4D4D4D] font-[600]'>Our Clients</h1>
                <p className='text-[20px] text-[#4D4D4D] font-[400]'>We have been working with some Fortune 500+ clients</p>
            </div>
            {/* clients brand logo */}
            <div className='flex justify-between mt-[16px]'>
                <img src="./logo/Logo (1).png" alt="" />
                <img src="./logo/Logo (2).png" alt="" />
                <img src="./logo/Logo (3).png" alt="" />
                <img src="./logo/Logo (4).png" alt="" />
                <img src="./logo/Logo (5).png" alt="" />
                <img src="./logo/Logo (6).png" alt="" />
                <img src="./logo/Logo (7).png" alt="" />

            </div>

        </div>
    </>
  )
}

export default Clients