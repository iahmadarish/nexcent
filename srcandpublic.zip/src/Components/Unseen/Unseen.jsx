import React from 'react'

const Unseen = () => {
  return (
    <div>
         <div className='max-w-6xl mx-auto py-[150px] flex justify-between'>
            {/* images */}
            <div>
                <img src="./unseen/unseen.png" alt="" />
            </div>
            {/* details */}


            <div>
                <h1 className='mb-[16px] text-[36px] w-[500px] leading-10 font-semibold text-[#4D4D4D]'>The unseen of spending three years at Pixelgrade </h1>
                <p className='w-[600px] text-base text-[#717171] font-[500] mb-10 leading-5	'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet justo ipsum. Sed accumsan quam vitae est varius fringilla. Pellentesque placerat vestibulum lorem sed porta. Nullam mattis tristique iaculis. Nullam pulvinar sit amet risus pretium auctor. Etiam quis massa pulvinar, aliquam quam vitae, tempus sem. Donec elementum pulvinar odio.</p>
                <a className=' border-0	bg-[#4CAF4F] px-[30px] py-[14px] rounded-xl text-[20px] font-[500]' href=""> Learn more </a>
            </div>
        </div>
    </div>
  )
}

export default Unseen