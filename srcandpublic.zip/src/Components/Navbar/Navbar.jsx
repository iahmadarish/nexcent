import React from 'react'

const Navbar = () => {
  return (
    <div>
        <div className='max-w-6xl mx-auto mt-10 flex'>
            <div className='w-1/5 '> <img src="./logo/Logo.png" alt="logo" /> </div>
            <div className='w-4/5 flex justify-around '> 
                <div> 
                    <ul className='flex gap-x-12 items-center'>
                        <li><a className='text-[20px] font-semibold ' href="">Home</a></li>
                        <li><a className='text-[20px] font-semibold ' href="">Service</a></li>
                        <li><a className='text-[20px] font-semibold ' href="">Feature</a></li>
                        <li><a className='text-[20px] font-semibold ' href="">Product</a></li>
                        <li><a className='text-[20px] font-semibold ' href="">Testimonial</a></li>
                        <li><a className='text-[20px] font-semibold ' href="">FAQ</a></li>
                    </ul>
                </div>
                <div className='flex gap-x-[30px]'>
                    <a className='text-base font-bold text-[#4CAF4F]' href=""> Log in </a>
                    <a className='border-0	 bg-[#4CAF4F] px-[30px] py-[14px] rounded-xl text-[20px] font-[500] ' href=""> Sign up </a>
                </div>
            
            </div>
        </div>
    </div>
  )
}

export default Navbar