import React from 'react'

const Banner = () => {
  return (
    <div>
        <div className='max-w-6xl mx-auto py-[150px] flex justify-between'>
            {/* detils */}
            <div>
                <h1 className='text-[64px] font-[semibold]'>Lessons and insights </h1>
                <h1 className='text-[64px] text-[#4CAF4F] font-[semibold]'>from 8 years </h1>
                <p className='text-base font-[500] mb-10'>Where to grow your business as a photographer: site or social media?</p>
                <a className=' border-0	bg-[#4CAF4F] px-[30px] py-[14px] rounded-xl text-[20px] font-[500]' href=""> Register </a>
            </div>
            {/* image */}
            <div>
                <img src="./images/hero.png" alt="" />
            </div>
        </div>
    </div>
  )
}

export default Banner