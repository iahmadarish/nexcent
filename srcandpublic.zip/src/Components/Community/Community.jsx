import React from 'react'

const Community = () => {
  return (
    <>
    <div className='max-w-6xl mx-auto mb-10 mt-10'>
        <div className=''>
            <h1 className='text-[36px] font-semibold text-[#4D4D4D] w-[542px] leading-[50px] text-center mx-auto'>Manage your entire community in a single system</h1>
            <p className='text-base text-[#717171] text-center'>Who is Nextcent suitable for?</p>
        </div>
        <div className='flex'>
            <div className='mx-auto text-center mt-10 shadow-lg	px-[10px] py-[20px]'>
                <h2 className='text-center'><img className='m-auto' src="./community/Icon.png" alt="" /></h2>
                <h1 className='text-[#4D4D4D] font-semibold text-[28px] w-[300px] mb-[7px] text-center'>Membership Organisations</h1>
                <p className='text-center mx-auto w-[251px]'>Our membership management software provides full automation of membership renewals and payments</p>
            </div>
            <div className='mx-auto text-center mt-10  shadow-lg	px-[10px] py-[20px]'>
                <h2 className='text-center'><img className='m-auto' src="./community/Icon (1).png" alt="" /></h2>
                <h1 className='text-[#4D4D4D] font-semibold text-[28px] w-[300px] mb-[7px] text-center'>Membership Organisations</h1>
                <p className='text-center mx-auto w-[251px]'>Our membership management software provides full automation of membership renewals and payments</p>
            </div>
            <div className='mx-auto text-center mt-10  shadow-lg	px-[10px] py-[20px]'>
                <h2 className='text-center'><img className='m-auto' src="./community/Icon (2).png" alt="" /></h2>
                <h1 className='text-[#4D4D4D] font-semibold text-[28px] w-[300px] mb-[7px] text-center'>Membership Organisations</h1>
                <p className='text-center mx-auto w-[251px]'>Our membership management software provides full automation of membership renewals and payments</p>
            </div>
        </div>
    </div>
    </>
  )
}

export default Community