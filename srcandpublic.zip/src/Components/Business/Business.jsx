import React from 'react'

const Business = () => {
  return (
    < >
        <div className='bg-[#F5F7FA] py-[115px]'>
        <div className='max-w-6xl mx-auto flex justify-evenly'>
            <div className=''>
                <h1 className='w-[380px] text-[36px] font-semibold leading-[39px] mb-4 '>Helping a local <span className='text-[#4CAF4F]'>business reinvent itself</span> </h1>
                <p className='text-base font-normal font-[500] '>We reached here with our hard work and dedication</p>
            </div>
            <div className='flex flex-wrap	'>

                <div>
                    <img src="./business/Icon.png" alt="" />
                    <h1></h1>
                </div>

                <div>
                <img src="./business/Icon (1).png" alt="" />
                    <h1></h1>
                </div>

                <div>
                <img src="./business/Icon (2).png" alt="" />
                    <h1></h1>
                </div>

                <div>
                <img src="./business/Vector.png" alt="" />
                    <h1></h1>
                </div>

            </div>
        </div>
        </div>
    </>
  )
}

export default Business