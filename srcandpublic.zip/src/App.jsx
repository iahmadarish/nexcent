import Banner from "./Components/Banner/Banner"
import Business from "./Components/Business/Business"
import Clients from "./Components/Clients/Clients"
import Community from "./Components/Community/Community"
import Navbar from "./Components/Navbar/Navbar"
import Unseen from "./Components/Unseen/Unseen"


function App() {

  return (
    <>
     <Navbar></Navbar>
     <Banner></Banner>
     <Clients></Clients>
     <Community></Community>
     <Unseen></Unseen>
     <Business></Business>
    </>
  )
}

export default App
